<?global $sotbitFilterResult;  
$sotbitFilterResult = $arResult;?>