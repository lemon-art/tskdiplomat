<?
$MESS["CT_BCSF_FILTER_TITLE"] = "Вибір за параметрами:";
$MESS["CT_BCSF_FILTER_FROM"] = "Від";
$MESS["CT_BCSF_FILTER_TO"] = "До";
$MESS["CT_BCSF_SET_FILTER"] = "Показати";
$MESS["CT_BCSF_DEL_FILTER"] = "Скинути";
$MESS["CT_BCSF_FILTER_COUNT"] = "Обрано: #ELEMENT_COUNT#";
$MESS["CT_BCSF_FILTER_SHOW"] = "Показати";
$MESS["CT_BCSF_FILTER_ALL"] = "Всі";
?>