<?
$MESS["CT_BCSF_FILTER_TITLE"] = "Auswählen nach:";
$MESS["CT_BCSF_FILTER_FROM"] = "Von";
$MESS["CT_BCSF_FILTER_TO"] = "Bis";
$MESS["CT_BCSF_SET_FILTER"] = "Anzeigen";
$MESS["CT_BCSF_DEL_FILTER"] = "Zurücksetzen";
$MESS["CT_BCSF_FILTER_COUNT"] = "Ausgewählt: #ELEMENT_COUNT#";
$MESS["CT_BCSF_FILTER_SHOW"] = "Anzeigen";
$MESS["CT_BCSF_FILTER_ALL"] = "Alle";
?>