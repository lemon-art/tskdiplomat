<?
$MESS["CP_BCSF_PRICES"] = "Preise";
$MESS["CP_BCSF_IBLOCK_TYPE"] = "Informationsblocktyp";
$MESS["CP_BCSF_IBLOCK_ID"] = "Informationsblock";
$MESS["CP_BCSF_SECTION_ID"] = "ID des Informationsblockbereichs";
$MESS["CP_BCSF_SECTION_CODE"] = "Bereichscode";
$MESS["CP_BCSF_PRICE_CODE"] = "Preistyp";
$MESS["CP_BCSF_FILTER_NAME"] = "Name des ausgehenden Arrays für die Filterung";
$MESS["CP_BCSF_SAVE_IN_SESSION"] = "Filtereinstellungen in der Usersession speichern";
$MESS["CP_BCSF_CACHE_GROUPS"] = "Zugriffsrechte berücksichtigen";
$MESS["CP_BCSF_INSTANT_RELOAD"] = "Sofortiges Filtern mithilfe von AJAX";
$MESS["CP_BCSF_GROUP_XML_EXPORT"] = "Unterstützung für YandexInsel (Export des Filters nach XML)";
$MESS["CP_BCSF_XML_EXPORT"] = "YandexInsel aktivieren";
$MESS["CP_BCSF_SECTION_TITLE"] = "Überschrift";
$MESS["CP_BCSF_SECTION_DESCRIPTION"] = "Beschreibung";
$MESS["CP_BCSF_HIDE_NOT_AVAILABLE"] = "Produkte ausblenden, die nicht auf Lager sind";
$MESS["CP_BCSF_CONVERT_CURRENCY"] = "Preise in einer Währung anzeigen";
$MESS["CP_BCSF_CURRENCY_ID"] = "Währung in die die Preise konvertiert werden";
$MESS["CP_BCSF_SMART_FILTER_PATH"] = "Parameter des Smart-Filters";
$MESS["CP_BCSF_SECTION_CODE_PATH"] = "Pfad aus mnemonischen Codes der verschachtelten Bereiche ableiten";
$MESS["CP_BCSF_PAGER_PARAMS_NAME"] = "Name des Bereichs mit Variablen zum Aufbau der Breadcrumb-Links";
?>