<?
$MESS["CD_BCSF_CATALOG"] = "Catalog";
$MESS["CD_BCSF_DESCRIPTION"] = "Displays elements filter form";
$MESS["CD_BCSF_NAME"] = "Smart filter";
?>