<?
$MESS ['CC_BCF_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
?>