<?
$MESS["CP_BCSF_PRICES"] = "Prices";
$MESS["CP_BCSF_IBLOCK_TYPE"] = "Infoblock type";
$MESS["CP_BCSF_IBLOCK_ID"] = "Infoblock";
$MESS["CP_BCSF_SECTION_ID"] = "Information block section ID";
$MESS["CP_BCSF_SECTION_CODE"] = "Section code";
$MESS["CP_BCSF_PRICE_CODE"] = "Price type";
$MESS["CP_BCSF_FILTER_NAME"] = "Name of result filter array";
$MESS["CP_BCSF_SAVE_IN_SESSION"] = "Store filter settings in user session";
$MESS["CP_BCSF_CACHE_GROUPS"] = "Respect Access Permissions";
$MESS["CP_BCSF_INSTANT_RELOAD"] = "Instant filter using AJAX";
$MESS["CP_BCSF_GROUP_XML_EXPORT"] = "Support YandexIsland (export filter to XML)";
$MESS["CP_BCSF_XML_EXPORT"] = "Enable YandexIsland";
$MESS["CP_BCSF_SECTION_TITLE"] = "Title";
$MESS["CP_BCSF_SECTION_DESCRIPTION"] = "Description";
$MESS["CP_BCSF_HIDE_NOT_AVAILABLE"] = "Hide items not in stock";
$MESS["CP_BCSF_CONVERT_CURRENCY"] = "Use only one currency to show prices";
$MESS["CP_BCSF_CURRENCY_ID"] = "Convert all prices to currency";
$MESS["CP_BCSF_SMART_FILTER_PATH"] = "Smart filter parameters";
$MESS["CP_BCSF_SECTION_CODE_PATH"] = "Path using mnemonic codes of nested sections";
$MESS["CP_BCSF_PAGER_PARAMS_NAME"] = "The name of an array with variables to build breadcrumb links";
?>