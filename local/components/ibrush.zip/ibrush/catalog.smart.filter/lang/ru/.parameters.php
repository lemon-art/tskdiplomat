<?
$MESS["CP_BCSF_PRICES"] = "Цены";
$MESS["CP_BCSF_IBLOCK_TYPE"] = "Тип инфоблока";
$MESS["CP_BCSF_IBLOCK_ID"] = "Инфоблок";
$MESS["CP_BCSF_SECTION_ID"] = "ID раздела инфоблока";
$MESS["CP_BCSF_SECTION_CODE"] = "Код раздела";
$MESS["CP_BCSF_PRICE_CODE"] = "Тип цены";
$MESS["CP_BCSF_FILTER_NAME"] = "Имя выходящего массива для фильтрации";
$MESS["CP_BCSF_SAVE_IN_SESSION"] = "Сохранять установки фильтра в сессии пользователя";
$MESS["CP_BCSF_CACHE_GROUPS"] = "Учитывать права доступа";
$MESS["CP_BCSF_INSTANT_RELOAD"] = "Мгновенная фильтрация при включенном AJAX";
$MESS["CP_BCSF_GROUP_XML_EXPORT"] = "Поддержка Яндекс Островов (экспорт фильтра в XML)";
$MESS["CP_BCSF_XML_EXPORT"] = "Включить поддержку Яндекс Островов";
$MESS["CP_BCSF_SECTION_TITLE"] = "Заголовок";
$MESS["CP_BCSF_SECTION_DESCRIPTION"] = "Описание";
$MESS["CP_BCSF_HIDE_NOT_AVAILABLE"] = "Не отображать товары, которых нет на складах";
$MESS["CP_BCSF_CONVERT_CURRENCY"] = "Показывать цены в одной валюте";
$MESS["CP_BCSF_CURRENCY_ID"] = "Валюта, в которую будут сконвертированы цены";
$MESS["CP_BCSF_SMART_FILTER_PATH"] = "Блок ЧПУ умного фильтра";
$MESS["CP_BCSF_SECTION_CODE_PATH"] = "Путь из символьных кодов раздела";
$MESS["CP_BCSF_PAGER_PARAMS_NAME"] = "Имя массива с переменными для построения ссылок в постраничной навигации";
?>