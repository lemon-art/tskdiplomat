<?
$MESS["CD_BCSF_CATALOG"] = "Каталог";
$MESS["CD_BCSF_NAME"] = "Умный фильтр";
$MESS["CD_BCSF_DESCRIPTION"] = "Выводит форму фильтра для фильтрации элементов инфоблоков";
?>