<?
$MESS["CD_BCSF_CATALOG"] = "Каталог";
$MESS["CD_BCSF_DESCRIPTION"] = "Виводить форму фільтра для фільтрації елементів інфоблоків";
$MESS["CD_BCSF_NAME"] = "Розумний фільтр";
?>