<?
$MESS["CP_BCSF_PRICES"] = "Ціни";
$MESS["CP_BCSF_IBLOCK_TYPE"] = "Тип інфоблоку";
$MESS["CP_BCSF_IBLOCK_ID"] = "Інфоблок";
$MESS["CP_BCSF_PRICE_CODE"] = "Тип ціни";
$MESS["CP_BCSF_FILTER_NAME"] = "Ім'я масиву ,що виходить для фільтрації";
$MESS["CP_BCSF_SAVE_IN_SESSION"] = "Зберігати установки фільтра в сесії користувача";
$MESS["CP_BCSF_CACHE_GROUPS"] = "Враховувати права доступу";
$MESS["CP_BCSF_SECTION_ID"] = "ID розділу інфоблоку";
$MESS["CP_BCSF_SECTION_CODE"] = "Код розділу";
$MESS["CP_BCSF_INSTANT_RELOAD"] = "Миттєва фільтрація при ввімкненому AJAX";
$MESS["CP_BCSF_SECTION_TITLE"] = "Тема";
$MESS["CP_BCSF_SECTION_DESCRIPTION"] = "Опис";
$MESS["CP_BCSF_GROUP_XML_EXPORT"] = "Підтримка Яндекс.Островів (експорт фільтра в XML)";
$MESS["CP_BCSF_XML_EXPORT"] = "Включити підтримку Яндекс.Островів";
$MESS["CP_BCSF_HIDE_NOT_AVAILABLE"] = "Не відображати товари, яких немає на складах";
$MESS["CP_BCSF_CONVERT_CURRENCY"] = "Показувати ціни в одній валюті";
$MESS["CP_BCSF_CURRENCY_ID"] = "Валюта, в яку будуть сконвертовані ціни";
?>