<?
$MESS["CC_BCF_MODULE_NOT_INSTALLED"] = "Модуль Інформаційних блоків не встановлено";
?>